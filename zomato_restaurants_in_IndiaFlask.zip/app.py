from flask import Flask, render_template, request
import pandas as pd

# Sample DataFrame
data = pd.read_csv('zomato_restaurants_in_India.csv')
data.drop_duplicates(["res_id"],keep='first',inplace=True)
data = data.dropna(subset=['cuisines'])
# Create DataFrame
df = data
print(len(df))

app = Flask(__name__)

@app.route('/')
def index():
    text_ratings = df['rating_text'].unique()
    city = sorted(list(df['city'].unique()))
    cuisine_types = sorted(map(str, df['cuisines'].str.split(', ').explode().unique()))
    city_localities = df.groupby('city')['locality'].unique().apply(list).to_dict()
    return render_template('index.html', text_ratings = text_ratings, cuisine_types=cuisine_types, cities= city, city_localities = city_localities)

@app.route('/recommend', methods=['POST'])
def recommend():
    city_input = request.form['city']
    locality_input = request.form['locality']
    aggregate_rating_input = float(request.form['aggregate_rating'] or 0)
    text_rating_input = request.form['text_rating']
    cost_for_two_input = float(request.form['cost_for_two'] or 99999)
    cuisine_type_input = request.form['cuisine_type']

    print(city_input,locality_input,aggregate_rating_input,text_rating_input,cost_for_two_input, cuisine_type_input)

    if city_input:
        filtered_df = df[df['city'] == city_input]
    else:
        filtered_df = df
    print(len(filtered_df))

    if locality_input:
        filtered_df = filtered_df[filtered_df['locality'] == locality_input]
        print(len(filtered_df))
    if aggregate_rating_input:
        filtered_df = filtered_df[filtered_df['aggregate_rating'] >= aggregate_rating_input]
        print(len(filtered_df))
    if text_rating_input:
        filtered_df = filtered_df[filtered_df['rating_text'] == text_rating_input]
        print(len(filtered_df))
    if cost_for_two_input:
        filtered_df = filtered_df[filtered_df['average_cost_for_two'] <= cost_for_two_input]
        print(len(filtered_df))
    if cuisine_type_input:
        filtered_df = filtered_df[filtered_df['cuisines'].str.contains(cuisine_type_input, case=False)]
        print(len(filtered_df))

    top_5_restaurants = filtered_df.nlargest(5, 'aggregate_rating')
    print(len(top_5_restaurants))
    
    return render_template('result.html', restaurants=top_5_restaurants)

if __name__ == '__main__':
    app.run(debug=True)

